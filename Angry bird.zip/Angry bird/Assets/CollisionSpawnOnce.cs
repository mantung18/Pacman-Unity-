﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionSpawnOnce : MonoBehaviour {
    public GameObject feathers;
    Vector2 pos;
   
    // Use this for initialization
    void Start () {
		
	}

	// Update is called once per frame
	void Update () {
		
	}

    void OnCollisionEnter2D(Collision2D col)
    {   
        {
            pos = transform.position;
            Instantiate(feathers, pos, Quaternion.identity);
            Destroy(this);
        }
        
    }

    }
