﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PullAndRelease : MonoBehaviour {
    Vector2 startPos;
    public float force = 1300;
    // Use this for initialization
    void Start () {
        startPos = transform.position;
    }

    void OnMouseUp()
    {
        // ToDo: fire the Bird
        // Disable isKinematic
        GetComponent<Rigidbody2D>().isKinematic = false;

        // Add the Force
        Vector2 dir = startPos- (Vector2)transform.position;
        GetComponent<Rigidbody2D>().AddForce(dir * force);

        // Remove the Script (not the gameObject)
        Destroy(this);
    }

    void OnMouseDrag()
    {
        // ToDo: move the Bird
        Vector2 p = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        float radius = 1.8f;
        Vector2 dir =  p - startPos;
        if (dir.sqrMagnitude > radius)
            dir = dir.normalized * radius;
            //Debug.Log(dir);


        transform.position = startPos + dir;
    }


    // Update is called once per frame
    void Update () {
		
	}
}
