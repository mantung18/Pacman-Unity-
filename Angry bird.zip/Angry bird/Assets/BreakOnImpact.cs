﻿using UnityEngine;
using System.Collections;

public class BreakOnImpact : MonoBehaviour
{
    public float forceNeeded = 700;
    //float ori;

    void Start()
    {
        
    }
   void Update()
    {
        //ori = gameObject.GetComponent<Rigidbody2D>().velocity.sqrMagnitude;
        //Debug.Log(ori);
    }

    float collisionForce(Collision2D coll)
    {
        // Estimate a collision's force (speed * mass)
        
        float speed = coll.relativeVelocity.sqrMagnitude; //sqrmagnitude much faster than magnitude (Wood49 vs 7)
       
        //Debug.Log(speed + "hi");
       
        if (coll.collider.GetComponent<Rigidbody2D>())
        { //Debug.Log (speed * coll.collider.GetComponent<Rigidbody2D>().mass);
            return speed * coll.collider.GetComponent<Rigidbody2D>().mass;
        }
        /*{
            Debug.Log(coll.collider.GetComponent<Rigidbody2D>().velocity.sqrMagnitude);
            Debug.Log(coll.collider.GetComponent<Rigidbody2D>().velocity.sqrMagnitude * coll.collider.GetComponent<Rigidbody2D>().mass);
            return coll.collider.GetComponent<Rigidbody2D>().velocity.sqrMagnitude;

        }*/
        return speed;
       // return 1;
    }

    void OnCollisionEnter2D(Collision2D coll)
    {
        
        if (collisionForce(coll) >= forceNeeded)
            Destroy(gameObject);
    }
}

