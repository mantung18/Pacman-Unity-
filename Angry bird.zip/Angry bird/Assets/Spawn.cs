﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour {

    public GameObject birdPrefab;

    // Is there a Bird in the Trigger Area?
    bool occupied = false;
    int isMoving = 3 ;
    


    // Use this for initialization
    void Start () {
        spawnNext();
    }

    void spawnNext()
    {
        Instantiate(birdPrefab, transform.position, Quaternion.identity);
        occupied = true;
    }

    void OnTriggerExit2D(Collider2D other)
    {
        occupied = false;
    }

    void sceneMoving()
    {
        // Find all Rigidbodies, see if any is still moving a lot
        Rigidbody2D[] bodies = FindObjectsOfType(typeof(Rigidbody2D)) as Rigidbody2D[];
        foreach (Rigidbody2D rb in bodies)
        {
            //Debug.Log(rb.velocity.sqrMagnitude);
            if (rb.velocity.sqrMagnitude > 5)
            {
                //Debug.Log(isMoving);
                isMoving = 1;
                //Debug.Log(isMoving);
                return;
            }
            
        }
        isMoving = 0;
        //Debug.Log(isMoving);


    }

    // Update is called once per frame
    void Update () {
        //Vector3 pos = new Vector3(-16, 3, 0);
        sceneMoving(); //check if there is still object moving 
  
        if (occupied == false && isMoving == 0)
        {
            spawnNext();
        }
    }
}
